package com.example.adspot;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import static android.provider.AlarmClock.EXTRA_MESSAGE;

public class MainActivity extends AppCompatActivity {
    public static final String EXTRA_MESSAGE = "com.example.myfirstapp.MESSAGE";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView invalidLogin = findViewById(R.id.invalidLogin);
        invalidLogin.setText(""); //make blank
    }

    public void sendMessage(View view) {
        Intent intent = new Intent(this, ProviderHomeActivity.class);
        Intent intent2 = new Intent(this, ConsumerHomeActivity.class);

        //Send Username
        EditText editText = (EditText) findViewById(R.id.editText);
        String message = editText.getText().toString();

        //Send Password
        EditText editText2 = (EditText) findViewById(R.id.editText2);
        String message2 = editText2.getText().toString();

        String master = message + "." + message2;

        int search = searchTable(master);

        if (search == 1) { //Provider
            intent.putExtra(EXTRA_MESSAGE, master);
            startActivity(intent);
        }
        else if (search == 2) { //Consumer
            intent2.putExtra(EXTRA_MESSAGE, master);
            startActivity(intent2);
        }
        else {
            TextView invalidLogin = findViewById(R.id.invalidLogin);
            invalidLogin.setText("Invalid Username or Password");
        }
    }

    private int searchTable(String user)
    {
        String[][] userTable = new String[5][5];
        userTable[0][0] = "Provider.pp"; userTable[0][1] = "P";
        userTable[1][0] = "Consumer.cc"; userTable[1][1] = "C";
        userTable[2][0] = "MrHappy.mm"; userTable[2][1] = "C";
        userTable[3][0] = "MrSad.mm"; userTable[3][1] = "C";

        for (int i = 0; i <= 3; i = i + 1) //search the table
        {
            if (user.equals(userTable[i][0])) { //found user
                user = userTable[i][1];
                if (user.equals("P")) {return 1;}
                if (user.equals("C")) {return 2;}
            }
        }
        return 0;
    }
}


