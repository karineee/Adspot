//edited
package com.example.adspot;

import android.content.Context;

import com.microsoft.windowsazure.mobileservices.MobileServiceClient;
import com.microsoft.windowsazure.mobileservices.table.DateTimeOffset;

public class RecommendationTable {

    private static MobileServiceClient mClient;
    private static Context mCon;
    private static RecommendationTable mInstance = null;

    @com.google.gson.annotations.SerializedName("Id")
    private String mID;
    public String getID() { return mID; }
    public final void setID(String ID) { mID = ID; }

    @com.google.gson.annotations.SerializedName("Rec1")
    private String mRec1;
    public String getRec1() { return mRec1; }
    protected void setRec1(String text) { mRec1 = text; }

    @com.google.gson.annotations.SerializedName("Link1")
    private String mLink1;
    public String getLink1() { return mLink1; }
    protected void setLink1(String text) { mLink1 = text; }

    @com.google.gson.annotations.SerializedName("Rec2")
    private String mRec2;
    public String getRec2() { return mRec2; }
    protected void setRec2(String text) { mRec2 = text; }

    @com.google.gson.annotations.SerializedName("Link2")
    private String mLink2;
    public String getLink2() { return mLink2; }
    protected void setLink2(String text) { mLink2 = text; }


    @com.google.gson.annotations.SerializedName("Rec3")
    private String mRec3;
    public String getRec3() { return mRec3; }
    protected void setRec3(String text) { mRec3 = text; }

    @com.google.gson.annotations.SerializedName("Link3")
    private String mLink3;
    public String getLink3() { return mLink3; }
    protected void setLink3(String text) { mLink3 = text; }




    public RecommendationTable() {}

    public RecommendationTable(String text, String text2) {
        //this.setId(id);
        this.setRec1(text);
        this.setLink1(text2);
    }


}
